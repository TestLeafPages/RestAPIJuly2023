package tests.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;
import lib.utils.ConfigurationManager;


public class TC002_CreateIncident_Test extends RESTAssuredBase{
	
	@BeforeTest//Reporting
	public void setValues() {
		testCaseName = "Create a new Incident (REST)";
		testDescription = "Create a new Incident and Verify";
		nodes = "Incident";
		authors = "Shan";
		category = "REST";
		//dataProvider
//	dataFileName = "TC001";
//		dataFileType = "JSON";
	}

	@Test
	public void createIncident() throws FileNotFoundException, IOException {		
		
     
		Response response = postWithJsonAsBody("{\r\n"
				+ "  \"description\": \"This is my first description\",\r\n"
				+ "  \"short_description\": \"This is my first SD\",\r\n"
				+ "  \"category\": \"software\"\r\n"
				+ "}", "incident");
		
		sys_id=response.jsonPath().get("result.sys_id");
		
		verifyResponseCode(response, ConfigurationManager.configuration().responsecodeforPost());
		
	}


}




















