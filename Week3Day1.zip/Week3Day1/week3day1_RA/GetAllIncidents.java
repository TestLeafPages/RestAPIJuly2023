package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents {
	
	@Test
	public void getIncidents() {
		
		
		//EndPoint

		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";

		// Authorization

		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
		
		//Add QueryParam
		
		RequestSpecification inputRequest =
				
		RestAssured.given()
	.queryParam("sysparm_fields", "sys_id,urgency,short_description,description");
		
		
		Response response = inputRequest.get("/incident");
		
		response.prettyPrint();
	}

}
