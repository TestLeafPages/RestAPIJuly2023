package week1day1;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithFile {
	
	@Test
	public void incidentCreationwithFile() {
		
		// Add Endpoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		// Add Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "d-J+lC2Hk7Aj");
		
		//Add Request
		
		File filePath=new File("./src/test/resources/CreateIncident.json");
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when()
				.body(filePath);
		
		//Send Request
		Response response = inputRequest.post("/incident");
		
		response.prettyPrint();
		
		//Get the response Code
		int statusCode = response.getStatusCode();
		
		System.out.println("The response code for create is -----"+statusCode);
		
		// Extract Sys_id
		String sys_id = response.jsonPath().get("result.sys_id");
		
		System.out.println("The value of sys_id is -------"+sys_id);
		
		
		
		
		
		
		
	}

}
