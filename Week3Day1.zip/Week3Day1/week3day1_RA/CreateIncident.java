package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {

	@Test
	public void incidentCreation() {
		
		//EndPoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		// Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
		
		
		//Add Request
		
		RequestSpecification inputRequest = 
		RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "    \"short_description\": \"Created via postman\"\r\n"
				+ "}");
		
		//  Send Request
		
		Response response = inputRequest.post("/incident");
		
		//print the response
		
		response.prettyPrint();
		
	}
}
