package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {

	@Test
	public void incidentUpdate() {


		//EndPoint

		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";

		// Authorization

		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");

		//Add Request

		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when().body("{\r\n"
				+ "    \"short_description\": \"Updated via RA  for second time\",\r\n"
				+ "    \"description\": \"Description Updated via RA for second time\"\r\n"
				+ "}");

		// Send the Request
		Response response = inputRequest.put("/incident/689f872b2f37611081e256f62799b675");

        response.prettyPrint();
        
        int statusCode = response.getStatusCode();
        
        System.out.println("The Status code is -------"+statusCode);




	}
}
