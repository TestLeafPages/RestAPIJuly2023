package steps;


import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {
	
	public static RequestSpecification inputRequest;
	public static Response response;
	public static String sys_id;
	
	@Given("Set base uri")
	public void setURI() {
	RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
	}
	
	@And("Set Auth")
	public void setAuth() {
		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
	}
	
	@When("Create incident with body {string}")
	public void createIncidentWithBody(String body) {
		
	//Add Request
		
		 inputRequest = 
		RestAssured.given()
		.contentType("application/json")
		.when().body(body);
		//  Send Request
		
		 response = inputRequest.post("/incident");
		
	}
	@Then("Validate response code as {int}")
	public void validateResponseCode(int statusCode) {
		
		response.then().assertThat().statusCode(statusCode);
	}
	
	@When("get incidents with queryparam {string} and {string}")
	public void getIncidentsWithQP(String key,String value) {
		
		inputRequest=RestAssured.given().queryParam(key, value);
		response=inputRequest.get("/incident");
	}
	
	@When("create incident with {string}")
	public void createIncidentWithFile(String fileName) {
		File filePath=new File("./src/test/resources/"+fileName);
		inputRequest=RestAssured.given().contentType("application/json").body(filePath);
		response=inputRequest.post("/incident");
		 sys_id = response.jsonPath().get("result.sys_id");
	}
	
	@When("update incident with body {string}")
	public void updateIncidentWithBody(String body) {
		
	//Add Request
		
		 inputRequest = 
		RestAssured.given()
		.contentType("application/json")
		.when().body(body);
		//  Send Request
		
		 response = inputRequest.put("/incident/"+sys_id);
		 
		 response.prettyPrint();
		
	}
	
	
	
	

}
