package cookies;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UseCookies {

	@Test
	public void cookiesForAuth() {
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		//Add QueryParams
		RequestSpecification inputRequest =
				
		RestAssured.given()
		.cookie("JSESSIONID","3831FB43BFD6F7E6762AD0DF0FE5E9D6")
        .queryParam("sysparm_fields", "sys_id,urgency,short_description,number");
	 /*  .queryParam("sysparm_limit", "3"); */
		
	/*	.queryParams("sysparm_fields", "sys_id,urgency,short_description,description","sysparm_limit","1");*/
		
	  /* .queryParams(queryParams);*/
		
Response response = inputRequest.get("/incident");
		
	response.prettyPrint();
	}
}
