package cookies;

import java.util.Map;
import java.util.Map.Entry;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllCookies {
    @Test 
	public void cookies() {
    	//EndPoint
		
    			RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
    			
    			// Authorization
    			
    			RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj"	);
    			
    			//Add Request
    			
    			RequestSpecification inputRequest = RestAssured.given()
    			.contentType("application/json")
    			.when()
    			.body("{\r\n"
    					+ "    \"short_description\": \"Tested via RA\"\r\n"
    					+ "}");
    			
    			//Send the request
    		 Response response = inputRequest.post("/incident");
    		 response.prettyPrint();
    		 
    		 Map<String, String> cookies = response.getCookies();
    		 for (Entry<String,String> eachCookies : cookies.entrySet()) {
    		//	 System.out.println("The Name of cookies are---"+eachCookies.getKey());
    		//	 System.out.println("The values are ---"+eachCookies.getValue());
				
			}
    		 
    		System.out.println("The value of JSession ID is--"+response.getCookie("JSESSIONID"));
    		 
    		 
    		 
    		 
    		 
    		 
		
	}
	
}
