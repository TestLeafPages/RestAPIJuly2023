package mocking;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;



public class SchemaValidation {
	
	@Test
	public void validateSchema() {
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
      RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
		RequestSpecification inputRequest = RestAssured.given()
				.contentType("application/json")
				.queryParam("sysparm_fields","sys_id,category")
				.when()
				.body("{\r\n"
						+ "    \"short_description\": \"Tested via RA\"\r\n"
						+ "}");
				
				//Send the request
				 Response response = inputRequest.post("/incident");
				//response.prettyPrint();
				 
				 File schemaFile=new File("./src/test/resources/SchemaFile.json");
				 
	response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schemaFile));
				 
				 
				 
				 
				 
				 
	}

}
