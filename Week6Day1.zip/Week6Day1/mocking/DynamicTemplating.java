package mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DynamicTemplating {
   @Test
	public void templating() {
	   RestAssured.baseURI="http://localhost/testleaf/training/course";
	   RequestSpecification inputRequest = RestAssured.given().queryParam("course_name", "Devops")
	   .queryParam("type", "online");
	   Response response = inputRequest.get();
	   response.prettyPrint();
		
		
	}
}
