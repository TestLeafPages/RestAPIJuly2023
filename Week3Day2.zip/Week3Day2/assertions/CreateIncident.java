package assertions;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends RestAssuredBase{

	
	@Test
	public void create() {
		
		
		//Add Request
		
		RequestSpecification inputRequest = RestAssured.given()
		.contentType("application/json")
		.when()
		.body("{\r\n"
				+ "    \"short_description\": \"Tested via RA\"\r\n"
				+ "}");
		
		//Send the request
		Response response = inputRequest.post("/incident");
		//response.prettyPrint();
		 sys_id = response.jsonPath().get("result.sys_id");
		 System.out.println("The sys_id is --------"+sys_id);
		 
		 // Extract Incident number
		  incNumber = response.jsonPath().get("result.number");
		  System.out.println(incNumber);
		 //Assert Status Code
		 
 response.then().assertThat().statusCode(Matchers.equalTo(201));
		 
		 //Assert short_description
		 
 response.then().assertThat().body("result.short_description",Matchers.equalTo("Tested via RA"));
 response.then().assertThat().body("result.short_description",Matchers.containsString("RA"));	 
		 // Assert Incident number
 response.then().assertThat().body("result.number",Matchers.containsString("INC"));
		 
		 
		 
		 
		
		
	}
}
