package assertions;

import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents extends RestAssuredBase {
	
	@Test(dependsOnMethods = "assertions.CreateIncident.create")
	public void getIncidents() {
		

		
		//Add QueryParams
		RequestSpecification inputRequest =
				
		RestAssured.given()
        .queryParam("sysparm_fields", "sys_id,urgency,short_description,number");
	 /*  .queryParam("sysparm_limit", "3"); */
		
	/*	.queryParams("sysparm_fields", "sys_id,urgency,short_description,description","sysparm_limit","1");*/
		
	  /* .queryParams(queryParams);*/
		
	Response response = inputRequest.get("/incident");
		
	//response.prettyPrint();
	// Assert value in collections --Matchers.hasItem
	
	response.then().assertThat().body("result.number", Matchers.hasItem(incNumber));
	}

}
