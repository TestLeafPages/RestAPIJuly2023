package assertions;

import io.restassured.RestAssured;

public class Jira {
	
	
	public void authJira() {
		
		RestAssured.authentication=RestAssured.preemptive().basic("feb2023restapi@gmail.com", "ATATT3xFfGF0HqLS2OkkQJ5k68KolhpN968I7LfMbbsPezisiOslvSjjhjh-J76OHQCa36-ghdgMPxzI3IjGSXe6zU9UiiMzdC1GsDTzNiTx-FFxsjeEWBygX96bUUSV4jVA81V6CzU14KqQSr-SGSQmU0UhI5I-L5cwGezZQaNFnzXbpphX_cQ=DFD8DB94");
	}

}
