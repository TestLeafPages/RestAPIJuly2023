package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class RestAssuredBase {

	public static String sys_id;
	
	@BeforeMethod
	public void setUp() {
		
	//EndPoint
		
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";
		
		// Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
	}
}
