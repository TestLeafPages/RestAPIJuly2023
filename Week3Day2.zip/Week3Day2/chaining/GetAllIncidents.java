package chaining;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents {
	
	@Test
	public void getIncidents() {
		
		
		//EndPoint

		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table";

		// Authorization

		RestAssured.authentication=RestAssured.basic("admin","d-J+lC2Hk7Aj");
		
		//Add QueryParam
		
		Map<String,String>queryParams=new HashMap<String,String>();
		queryParams.put("sysparm_fields", "sys_id,urgency,short_description,description");
		queryParams.put("sysparm_limit", "2");
		
		RequestSpecification inputRequest =
				
		RestAssured.given()
	/*   .queryParam("sysparm_fields", "sys_id,urgency,short_description,description")
	   .queryParam("sysparm_limit", "3"); */
		
	/*	.queryParams("sysparm_fields", "sys_id,urgency,short_description,description","sysparm_limit","1");*/
		
	   .queryParams(queryParams);
		
		Response response = inputRequest.get("/incident");
		
		response.prettyPrint();
	}

}
