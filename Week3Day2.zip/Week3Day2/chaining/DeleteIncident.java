package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident extends RestAssuredBase {

	@Test(dependsOnMethods = "chaining.UpdateIncident.update")
	public void delete() {
		
		Response response = RestAssured.delete("/incident/"+sys_id);
		int statusCode = response.getStatusCode();
		System.out.println("Delete status code------"+statusCode);
	}
}
