package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends RestAssuredBase{

	
	@Test
	public void create() {
		
		
		//Add Request
		
		RequestSpecification inputRequest = RestAssured.given()
		.contentType("application/json")
		.when()
		.body("{\r\n"
				+ "    \"short_description\": \"Tested via RA\"\r\n"
				+ "}");
		
		//Send the request
		Response response = inputRequest.post("/incident");
		//response.prettyPrint();
		 sys_id = response.jsonPath().get("result.sys_id");
		 System.out.println("The sys_id is --------"+sys_id);
		
		
	}
}
