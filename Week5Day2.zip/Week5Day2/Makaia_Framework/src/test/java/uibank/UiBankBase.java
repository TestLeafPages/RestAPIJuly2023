package uibank;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UiBankBase {
	
	public static String id;
	@BeforeMethod
	public void setUp() {
		// Login API to extract the id(token
		// Extracted Token should be used for Accounts API
		
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api";
		
		RequestSpecification inputRequest = RestAssured.given()
		.contentType("application/json")
		.when().body("{\r\n"
				+ "    \"username\": \"FebApiuser\",\r\n"
				+ "    \"password\": \"Eagle@123\"\r\n"
				+ "}");
		
		Response response = inputRequest.post("/users/login");
		
		//Extract the id and save it as Global variable
		
		 id = response.jsonPath().get("id");
		
		
		
	}

}
