package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateAccount extends UiBankBase {
	
	@Test
	public void create() {
		
		RequestSpecification inputRequest = RestAssured.given()
		.contentType("application/json")
		.header("authorization",id)
		.when()
		.body("{\r\n"
				+ "    \"friendlyName\": \"{{$randomFirstName}}\",\r\n"
				+ "    \"type\": \"savings\",\r\n"
				+ "    \"userId\": \"64290731ba9f8a0047adacfc\",\r\n"
				+ "    \"balance\": 100,\r\n"
				+ "    \"accountNumber\": 74322774\r\n"
				+ "}");
		
	
		Response response = inputRequest.post("/accounts");
		response.prettyPrint();
	}

}
